<?php
/**
 * Rights web user class file.
 *
 * @author Christoffer Niska <cniska@live.com>
 * @copyright Copyright &copy; 2010 Christoffer Niska
 * @since 0.5
 */
class AdminRWebUser extends RWebUser 
{
	public $fullname;
	
}