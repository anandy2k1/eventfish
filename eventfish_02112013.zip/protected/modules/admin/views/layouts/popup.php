<?php echo $content; ?> 
