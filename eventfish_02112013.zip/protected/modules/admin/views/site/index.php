<?php $this->breadcrumbs = array(); ?>
<div class="middle_inner">
    <div class="fix">
        <?php echo 'Welcome Admin'; ?>
        <div class="clear"></div>
    </div>
</div>
