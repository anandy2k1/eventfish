<?php

Yii::import('application.models._base.BaseCountryMaster');

class CountryMaster extends BaseCountryMaster {

    public static function model($className = __CLASS__) {
        return parent::model($className);
    }

}