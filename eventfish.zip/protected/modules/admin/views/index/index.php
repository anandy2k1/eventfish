<?php
$this->breadcrumbs = array(
    Yii::t('app', 'Dashboard')
);
?>
<p>&nbsp;</p>
<center><h1>Welcome to Event-Fish Admin Panel</h1></center>
