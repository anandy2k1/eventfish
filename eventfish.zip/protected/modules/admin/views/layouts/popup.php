<?php echo $content; ?> 
